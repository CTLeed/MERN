// import logo from './logo.svg';
import './App.css';
import Test from './components/new.js'

function App() {
  return (
    <div>
      <Test></Test>
    </div>
  );
}

export default App;
